@extends("base")
@section("title")
    {{$article->title}}
@endsection
@section("content")
    <div class="container-fluid" id="container-wrapper">
        <h1>{{$article->title}}</h1>
        <i>{{\Carbon\Carbon::parse($article->created_at)->format('j M, Y')}} </i>
        @if ($article->image)            
            <img src="{{ asset("storage/" . $article->image)  }}" class="card-img-top" alt="{{ $article->title }}" style="height: 350px;">
        @endif
        <div class="my-3">
            {!! $article->body !!}
        </div>
    </div>
@endsection