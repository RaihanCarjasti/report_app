@extends("base")
@section("title")
    Home
@endsection
@section("content")
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">Home</h1>
    </div>

    <div class="mb-3">
      <center>
        <form action="" method="POST" class="input-group my-3 w-75">
          @csrf
          <input type="text" name="q" class="form-control">
          <button class="btn btn-outline-primary" type="submit" id="button-addon2">Cari</button>
        </form>
      </center>
      <div class="row">
        @foreach ($articles as $article)
            <div class="col-12 col-sm-6 col-md-4">
                <div class="card mb-4">
                    <img src="{{ $article->image ? asset("storage/" . $article->image) : "https://picsum.photos/200/300" }}" class="card-img-top" alt="{{ $article->title }}" style="height: 250px;">
                    <div class="card-body">
                        <h5 class="card-title">{{ $article->title }}</h5>
                        <a href="{{ route("read", ["id"=>$article->id]) }}" class="btn btn-primary">Baca</a>
                    </div>
                </div>
            </div>
        @endforeach
      </div>
    </div>
@endsection
