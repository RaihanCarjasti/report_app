@extends("base")
@section("title")
    Hasil diagnosa
@endsection
@section("content")
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">Hasil</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Hasil</li>
      </ol>
    </div>

    <div class="mb-3">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h1>
                    {{$variable->name ?? "Hasil tidak diketahui"}}
                </h1>
            </div>
            <div class="card-body">
                {!! $variable->solution ?? "" !!}
            </div>
            <div class="card-footer">
                Nilai: {{$variable->naive ?? "0"}}
            </div>
        </div>

        <center>
            <button onclick="window.print()" class="btn btn-primary">
                Cetak
            </button>
            <a href="/analize" class="btn btn-warning">
                Kembali
            </a>
        </center>
        <link rel="stylesheet" href="{{ asset("fontawesome-free/css/all.min.css") }}">
        <link rel="stylesheet" href="{{ asset("bootstrap/css/bootstrap.min.css") }}" media="print">
        <link rel="stylesheet" href="{{ asset("css/ruang-admin.min.css") }}" media="print">
        <style>
            @media print {
                .nav, a, button, nav,.sidebar {
                    display: none;
                }
            }
        </style>
    </div>
@endsection
