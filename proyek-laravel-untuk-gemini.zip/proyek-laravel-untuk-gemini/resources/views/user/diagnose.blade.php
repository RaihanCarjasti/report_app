@extends("base")
@section("title")
    Analisa
@endsection
@section("content")
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
      <h1 class="h3 mb-0 text-gray-800">Analisa</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Analisa</li>
      </ol>
    </div>

    <form method="POST" class="mb-3">
        @csrf
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Kode indikator</th>
                <th scope="col">Nama indikator</th>
                <th scope="col">Keyakinan</th>
              </tr>
            </thead>
            <tbody>
            @foreach ($indicators as $indicator)                
            <tr>
              <th scope="row">I{{$loop->iteration }} </th>
              <td>{{$indicator->name}}</td>
              <td>
                {{-- <input name="cf-{{$indicator->id }}" min="0" max="1" step="0.1" type="number" value="{{ $cf[$indicator->id] ?? '0' }}" class="col-5 form-control"> --}}
                <select name="{{$indicator->id }}" class="col-5 form-control">
                    <option value="0">Tidak</option>
                    <option value="1">Ya</option>
                  </select>
              </td>
            </tr>
            {{-- @include("components.deleteModal",["id" => $indicator->id ,"item" => "Gejala","data" => $indicator->name,"delete_route" => "deleteSymptom"]) --}}
            @endforeach
            </tbody>    
          </table>
          <center>
            <button class="btn btn-primary">Cek</button>
          </center>
    </form>
@endsection