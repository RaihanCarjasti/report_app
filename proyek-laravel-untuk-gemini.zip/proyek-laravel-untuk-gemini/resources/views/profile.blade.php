@extends("base")
@section("title")
    Profil
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Profil</h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Profil</li>
        </ol>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card mb-5">
                <div class="card-body">            
                    <img class="img-profile rounded-circle" src="/img/boy.png" style="max-width: 150px;">
                    <br>
                    <p class="text-md-end">
                        Username: {{Auth::user()->username}}
                    </p>
                    <span class="text-md-end">
                        Nama: {{Auth::user()->name}}
                    </span>
                    <form action="{{ route("profile") }}" method="POST">
                        @csrf
        
                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password lama') }}</label>
        
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('oldpassword') is-invalid @enderror" name="oldpassword" required autocomplete="current-password">
                            </div>
                            @error('oldpassword')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password baru') }}</label>
        
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('newpassword') is-invalid @enderror" name="newpassword" required autocomplete="current-password">
        
                                @error('newpassword')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <button type="submit" class="btn btn-primary">
                                {{ __('Ubah password') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection