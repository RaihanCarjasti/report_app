@extends("base")
@section("title")
    {{$title}}
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{$title}}</h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">{{$title}}</li>
        </ol>
    </div>
    <form action="" method="POST">
        @csrf
        <div class="row mb-3">
            <label for="name" class="col">
                Nama
            </label>
            <div class="col-10">
                <input required type="text" maxlength="50" name="name" value="{{ $user->name ?? '' }}" class="form-control">
            </div>
        </div>
        <div class="row mb-3">
            <label for="rak" class="col">
                Username
            </label>
            <div class="col-10">
                <input required type="text" name="username" value="{{ $user->username ?? '' }}" class="form-control @error('username') is-invalid @enderror">
                @error('username')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
        <div class="row mb-3">
            <label for="rak" class="col">
                Role
            </label>
            <div class="col-10">
                <select required name="role" value="{{ $user->role ?? '' }}" class="form-control @error('role') is-invalid @enderror">
                    <option value="assesor">Penjamin mutu</option>
                    <option value="reviewer">Reviewer</option>
                </select>
                @error('role')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>
        </div>
        <div class="row mb-3">      
            <label for="rak" class="col">
                Password
            </label>
            <div class="col-10">
                <input required type="password" name="password" value="{{ $book->publisher ?? '' }}" class="form-control">
            </div>
        </div>
        <br>
        <br>
        <button class="btn btn-info">Simpan</button>
    </form>
@endsection