@extends("base")
@section("title")
    {{$title}}
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">{{$title}} </h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Daftar tugas</li>        
        <li class="breadcrumb-item active" aria-current="page">{{$title}}</li>
        </ol>
    </div>
    <div class="mt-3">
      @if (Auth::user()->role == "admin")
        
      <a href="{{ route("inputDocument",["criteria" => $title]) }}" class="btn btn-outline-success">Tambah</a>
      @endif
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Nomor</th>
                <th scope="col">Nama dokumen</th>
                <th scope="col">Tanggal ditambah</th>
                @if (Auth::user()->role == "admin" || Auth::user()->role == "reviewer")                
                  <th scope="col">Status</th>
                  <th scope="col">Aksi</th>
                @endif
              </tr>
            </thead>
            <tbody>
            @foreach ($documents as $document)                
            <tr>
              <th scope="row">{{$loop->iteration }} </th>
              <td><a href="{{ route("document", [ "doc" => $document->id,"criteria" => $title]) }}"> {{$document->name}} </a></td>
              <td>{{$document->created_at}}</td>
              @if (Auth::user()->role == "admin" || Auth::user()->role == "reviewer")                              
              <td>
                <span @class(['badge p-2', 'badge-success' => $document->status == "2",'badge-warning' => $document->status == "1",'badge-danger' => $document->status == "0"  || $document->status == null])>{{$document->status == "2"?"Sesuai": ($document->status == "1"?"Perlu direvisi":"Belum sesuai") }}</span>
              </td>
                <td>
                  @if (Auth::user()->role == "admin")                    
                    <a href="{{ route('editDocument', ["criteria" => $title,"doc" => $document->id]) }}" class="btn btn-info">Edit</a>
                    <button data-toggle="modal" data-target="#modal{{$document->id}}" class="btn btn-danger">
                      Hapus
                    </button>
                  @endif
                  @if (Auth::user()->role == "reviewer")
                    <a href="{{ route('addReview', ["criteria" => $title,"doc" => $document->id]) }}" class="btn btn-info">Tambah review</a>                    
                  @endif
                </td>
              @endif
            </tr>
            <div class="modal fade" id="modal{{$document->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Konfirmasi penghapusan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    Yakin menghapus Dokumen {{$document->name}}
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Tidak</button>
                    <a href="{{ route("deleteDocument", ["criteria"=>$title,"doc" => $document->id]) }}" class="btn btn-primary">Ya</a>
                  </div>
                </div>
              </div>
            </div>
            @endforeach
            </tbody>    
          </table>
      </div>
@endsection