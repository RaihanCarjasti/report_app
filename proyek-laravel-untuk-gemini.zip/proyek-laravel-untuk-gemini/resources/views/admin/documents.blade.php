@extends("base")
@section("title","Daftar dokumen")
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Daftar dokumen</h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Daftar dokumen</li>
        </ol>
    </div>
    <div class="mt-3">       
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Nomor</th>
                <th scope="col">Nama dokumen</th>
                <th scope="col">Tanggal ditambah</th>
                <th scope="col">Status</th>s      
              </tr>
            </thead>
            <tbody>
            @foreach ($documents as $document)                
            <tr>
              <th scope="row">{{$loop->iteration }} </th>
              <td><a href="{{ route("document", ["criteria"=>$document->type,"doc" => $document->id]) }}"> {{$document->name}} </a></td>
              <td>{{$document->created_at}}</td>
              <td>
                <span @class(['badge p-2', 'badge-success' => $document->passed,'badge-danger' => !$document->passed && $document->comment != null,'badge-warning' => !$document->passed && $document->comment == null])>{{$document->passed?"Lolos": ($document->comment!=null?"Belum lolos":"Belum direview") }}</span>
              </td>
            </tr>

            @endforeach
            </tbody>    
          </table>
      </div>
@endsection