@extends("base")
@section("title")
    Admin
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Daftar admin</h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Daftar admin</li>
        </ol>
    </div>
    <div class="mt-3">
        <a href="{{ route("inputAdmin") }}" class="btn btn-outline-success">Tambah</a>
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">Nomor</th>
                <th scope="col">Nama</th>
                <th scope="col">Username</th>
                <th scope="col">Jenis akun</th>
                <th scope="col">Aksi</th>
              </tr>
            </thead>
            <tbody>
            @foreach ($users as $user)                
            <tr>
              <th scope="row">{{$loop->iteration }} </th>
              <td>{{$user->name}}</td>
              <td>{{$user->username}}</td>
              <td>
                @if ($user->role == "assesor")                    
                  <span class="badge badge-primary">penjamin mutu</span>
                @else
                  <span class="badge badge-primary">{{$user->role}}</span>
                @endif
              </td>
              <td>
                <a href="{{ route("editAdmin", ["id"=>$user->id]) }}" class="btn btn-info">Edit</a>
                <button data-toggle="modal" data-target="#modal{{$user->id}}" class="btn btn-danger">
                  Hapus
                </button>
              </td>
            </tr>
            @include("components.deleteModal",["id" => $user->id,"item" => "Petugas","data" => $user->name,"delete_route" => "deleteAdmin"])
            @endforeach
            </tbody>    
          </table>
      </div>
@endsection