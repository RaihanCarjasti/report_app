@extends("base")
@section("title")
    Input tugas
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Input tugas</h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Input tugas</li>
        </ol>
    </div>
    <form action="" method="POST">
        @csrf
        <div class="row mb-3">
            <label for="name" class="col">
                Nama tugas
            </label>
            <div class="col-10">
                <input required type="text" maxlength="50" name="name" value="{{ $task->name ?? '' }}" class="form-control">
            </div>
        </div>
        <button class="btn btn-info">Simpan</button>

    </form>
@endsection