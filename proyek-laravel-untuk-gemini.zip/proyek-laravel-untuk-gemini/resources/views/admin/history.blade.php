@extends("base")
@section("title")
    Riwayat diagnosa
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Riwayat diagnosa</h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Riwayat diagnosa</li>
        </ol>
    </div>
    <div class="mt-3">
        {{-- <a href="{{ route("inputAdmin") }}" class="btn btn-outline-success">Tambah</a> --}}
        <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Hasil</th>
                <th scope="col">Tanggal</th>
              </tr>
            </thead>
            <tbody>
            @foreach ($histories as $key => $value)                
            <tr>
              <th scope="row">{{$loop->iteration }} </th>
              <td>{{$value["name"]}} P{{$value["id"]}}({{$value["score"] * 100}}%) </td>
              <td>{{$key}}</td>
            @endforeach
            </tbody>    
          </table>
        </div>
@endsection