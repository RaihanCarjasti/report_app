@extends("base")
@section("title",$title."/".$document->name)
@section("content")
<div class="card">
    <div class="card-body">
        <h3 class="row mb-3">
            <label for="name" class="col">
                <strong>
                    Nama
                </strong>
            </label>
            <div class="col-10">
                {{$document->name}}
            </div>
        </h3>
    
        <div class="row mb-3">
            <label for="document" class="col">
                <strong>
                    Dokumen
                </strong>
            </label>
            <div class="col-10">
                <a href="{{ asset("storage/".$document->path) }}">{{$document->path}} </a>
            </div>
        </div>
    
        <div class="row mb-3">
            <label for="review" class="col">
                <strong>
                    Review
                </strong>
            </label>
            <div class="col-10">
                @if ($document->comment)
                    {!! $document->comment !!}
                @else
                    <span>Belum ada review</span>
                @endif            
            </div>
        </div>
        <div class="row mb-3">
            <label for="review" class="col">
                <strong>
                    Kriteria
                </strong>
            </label>
            <div class="col-10">
                <span>{{$document->type}} </span>
            </div>
        </div>
        @if ($document->file_url != null)
            <div class="row mb-3">
                <label for="review" class="col">
                    <strong>
                        URL file
                    </strong>
                </label>
                <div class="col-10">
                    <a href="{{$document->file_url}}">{{ $document->file_url}} </a>
                </div>
            </div>
        @endif
        @if (Auth::user()->role == "admin" || Auth::user()->role == "reviewer")                                      
            <div class="row mb-3">
                <label for="review" class="col">
                    <strong>
                        Status
                    </strong>
                </label>
                <div class="col-10">
                    <span @class(['badge p-2', 'badge-success' => $document->status == "2",'badge-warning' => $document->status == "1",'badge-danger' => $document->status == "0"  || $document->status == null])>{{$document->status == "2"?"Sesuai": ($document->status == "1"?"Perlu direvisi":"Belum sesuai") }}</span>            
                </div>
            </div>
        @endif
    </div>

</div>
@endsection