@extends("base")
@section("title")
    {{$title}}
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah dokumen {{$title}} </h1>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Daftar tugas</li>        
        <li class="breadcrumb-item active" aria-current="page">{{$title}}</li>
        <li class="breadcrumb-item active" aria-current="page">Input dokumen</li>
        </ol>
    </div>
    <div class="card">
        <form  class="card-body" action="" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="row mb-3">
                <label for="name" class="col">
                    Nama dokumen
                </label>
                <div class="col-10">
                    <input required type="text" maxlength="50" name="name" value="{{ old('name', $document->name ?? '') }}" class="form-control @error('name') is-invalid @enderror">
                    
                    {{-- Error message for name --}}
                    @error('name')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        
            <div class="row mb-3">
                <label for="document" class="col">
                    Dokumen
                </label>
                <div class="col-10">
                    <input type="file" name="document" class="form-control @error('document') is-invalid @enderror">
                    
                    {{-- Error message for document --}}
                    @error('document')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            <div class="row mb-3">
                <label for="document" class="col">
                    URL file
                </label>
                <div class="col-10">
                    <input type="url" name="file_url" class="form-control @error('file_url') is-invalid @enderror">
                    
                    {{-- Error message for document --}}
                    @error('file_url')
                        <div class="text-danger">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            <button class="btn btn-info">Simpan</button>
        </form>
    </div>
    
@endsection