@extends("base")
@section("title","Tambah review")
@section("content")
<form action="" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="row mb-3">
        <label for="name" class="col">
            Nama dokumen
        </label>
        <div class="col-10">
            {{$document->name}}
        </div>
    </div>

    <div class="row mb-3">
        <label for="document" class="col">
            Dokumen
        </label>
        <div class="col-10">
            <a href="{{ asset("storage/".$document->path) }}">{{$document->path}} </a>
        </div>
    </div>

    <div class="row mb-3">
        <label for="review" class="col">
            Review
        </label>
        <div class="col-10">
            <textarea name="comment" class="form-control" id="" cols="30" rows="10">{{$document->comment ?? ""}} </textarea>
        </div>
    </div>

    <div class="row mb-3">
        <label for="review" class="col">
             Status
        </label>
        <div class="col-10">
            <select name="status" class="form-control">
                <option value="0" {{ optional($document)->status == "0" ? 'selected' : '' }}>Belum sesuai</option>
                <option value="1" {{ optional($document)->status == "1" ? 'selected' : '' }}>Perlu direvisi</option>
                <option value="2" {{ optional($document)->status == "2" ? 'selected' : '' }}>Sudah sesuai</option>
            </select>
            
        </div>
    </div>

    <button class="btn btn-info">Simpan</button>
</form>
@endsection