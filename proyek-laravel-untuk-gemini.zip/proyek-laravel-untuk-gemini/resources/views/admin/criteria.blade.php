@extends("base")
@section("title")
    {{$title}}
@endsection
@section("content")
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="./">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Daftar kriteria</li>
        </ol>
    </div>
    <div>
        <div class="list-group">
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 1"]) }}" class="list-group-item list-group-item-action">Kriteria 1</a>
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 2"]) }}" class="list-group-item list-group-item-action">Kriteria 2</a>
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 3"]) }}" class="list-group-item list-group-item-action">Kriteria 3</a>
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 4"]) }}" class="list-group-item list-group-item-action">Kriteria 4</a>        
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 5"]) }}" class="list-group-item list-group-item-action">Kriteria 5</a>        
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 6"]) }}" class="list-group-item list-group-item-action">Kriteria 6</a>        
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 7"]) }}" class="list-group-item list-group-item-action">Kriteria 7</a>        
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 8"]) }}" class="list-group-item list-group-item-action">Kriteria 8</a>        
            <a href="{{ route('typeCriteria', ['criteria'=>"kriteria 9"]) }}" class="list-group-item list-group-item-action">Kriteria 9</a>        
        </div>
    </div>
@endsection