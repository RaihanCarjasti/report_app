<style>
    .sidebar-grdient-dark, .sidebar{
        background-color: #ffffff;
    }
    .sidebar .nav .nav-item .nav-link{
        color: black;
        height: 1.5rem;
    }
    .sidebar .nav:not(.sub-menu) > .nav-item:hover:not(.nav-category):not(.nav-profile) > .nav-link{
        color: rgb(50, 47, 47);
    }
</style>
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item mb-3">
        <h5 class="fw-bolder" style="font-weight: 1000;">Data perpustakaan</h5>
        <a class="nav-link py-0 @if(Route::currentRouteName() == "category") text-primary @endif" href="{{ route("category") }}">
          <span class="menu-title">Kategori</span>
        </a>
        <a class="nav-link py-0 @if(Route::currentRouteName() == "book") text-primary @endif" href="{{ route("book") }}">
            <span class="menu-title">Buku</span>
        </a>
      </li>
      <li class="nav-item mb-3">
        <h5 class="fw-bolder" style="font-weight: 1000;">Data user</h5>
        <a class="nav-link py-0 @if(Route::currentRouteName() == "admin") text-primary @endif" href="{{ route("admin") }}">
          <span class="menu-title">Petugas</span>
        </a>
        <a class="nav-link py-0 @if(Route::currentRouteName() == "member") text-primary @endif" href="{{ route("member") }}">
            <span class="menu-title">Anggota</span>
        </a>
      </li>
      <li class="nav-item mb-3">
        <h5 class="fw-bolder" style="font-weight: 1000;">Transaksi</h5>
        <a class="nav-link py-0 @if(Route::currentRouteName() == "borrowBook") text-primary @endif" href="{{ route("borrowBook") }}">
          <span class="menu-title">Peminjaman</span>
        </a>
        <a class="nav-link py-0 @if(Route::currentRouteName() == "returnBook") text-primary @endif" href="{{ route("returnBook") }}">
            <span class="menu-title">Pengembalian</span>
        </a>
        {{-- <a class="nav-link py-0" href="index.html">
          <span class="menu-title">Denda</span>
        </a> --}}
      <li class="nav-item">
        <a class="nav-link" href="{{ route("logout") }}">
          <span class="menu-title"><strong>Logout</strong></span>
        </a>
        <a class="nav-link" href="{{ route("adminIndex") }}">
          <span class="menu-title"><strong>Profil</strong></span>
        </a>
      </li>
    </ul>
  </nav>