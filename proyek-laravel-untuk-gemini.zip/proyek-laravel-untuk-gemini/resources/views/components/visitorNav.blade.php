<nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark">
    <div class="container-fluid">
      <a class="navbar-brand text-white" href="#">Pengunjung</a>
      <div class="">
        <ul class="navbar-nav me-auto">
        </ul>
        <div class="d-flex">
          <button class="btn btn-warning my-2 my-sm-0" type="button" onclick="history.back()">Kembali</button>
          @auth  
            <a href="{{ route("logout") }}" class="btn btn-secondary my-2 my-sm-0 mx-3" type="button">Logout</a>
          @endauth
        </div>
      </div>
    </div>
  </nav>