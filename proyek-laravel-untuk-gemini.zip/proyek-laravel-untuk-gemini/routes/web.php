<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;

Route::group(["middleware" => ["auth"]], function () {
    Route::get("/", [AdminCOntroller::class,"index"])->name("index");
    Route::any("/profile", [AdminCOntroller::class,"profile"])->name("profile");
});

// Admin-only routes
Route::group(["middleware" => ["auth", "role:admin"]], function () {
    Route::any("/list", [AdminCOntroller::class,"admin"])->name("admin");
    Route::any("/admin/input", [AdminCOntroller::class,"inputAdmin"])->name("inputAdmin");
    Route::any("/admin/edit", [AdminCOntroller::class,"editAdmin"])->name("editAdmin");
    Route::post("/admin/delete", [AdminCOntroller::class,"deleteAdmin"])->name("deleteAdmin");

    // Route::any("/task/input", [AdminCOntroller::class,"inputTask"])->name("inputTask");
    // Route::any("/task/edit", [AdminCOntroller::class,"editTask"])->name("editTask");
    // Route::any("/task/delete", [AdminCOntroller::class,"deleteTask"])->name("deleteTask");
    
    Route::any("/criteria/{criteria}/input", [AdminCOntroller::class,"inputDocument"])->name("inputDocument");
    Route::any("/criteria/{criteria}/edit", [AdminCOntroller::class,"editDocument"])->name("editDocument");
    Route::any("/criteria/{criteria}/delete", [AdminCOntroller::class,"deleteDocument"])->name("deleteDocument");
    
});


Route::group(["middleware" => ["auth","role:admin,reviewer,assesor"]], function(){
    Route::any("/criteria/{criteria}", [AdminCOntroller::class,"typeCriteria"])->name("typeCriteria");
    Route::any("/document/{criteria}", [AdminController::class,"document"])->name("document");    
    Route::any("/document", [AdminController::class,"documents"])->name("documents"); 
});


Route::group(["middleware" => ["auth","role:reviewer"]], function(){
    Route::any("/review/{criteria}", [UserController::class,"addReview"])->name("addReview");    
});



Route::get("/logout", function(Request $request){
    Auth::logout();
 
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    
    return redirect("/");
 
});
Auth::routes();